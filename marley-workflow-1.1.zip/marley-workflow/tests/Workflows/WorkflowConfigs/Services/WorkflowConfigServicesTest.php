<?php

namespace App\Tests\Workflows\WorkflowConfigs\Services;

use PHPUnit\Framework\TestCase;

use App\Workflows\WorkflowConfigs\Services\WorkflowConfigServices;
use App\Workflows\WorkflowConfigs\Adapters\WorkflowConfigDBAdapter;
use App\Workflows\WorkflowConfigs\UseCases\WorkflowConfigUseCases;

class WorkflowConfigServicesTest extends TestCase
{
    /*
    public function test_getListOfWorkflowConfigs_checkAdapterIsCalled(): void
    {
        $mocked_adapter = $this->createMock(WorkflowConfigDBAdapter::class);
        $mocked_adapter->expects($this->once())
            ->method('getListOfWorkflowConfigs');
        
        $service = new WorkflowConfigServices();

        $service->getListOfWorkflowConfigs();
    }
    */
}
