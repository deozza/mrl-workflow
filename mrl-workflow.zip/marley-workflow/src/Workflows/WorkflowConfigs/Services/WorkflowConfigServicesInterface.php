<?php

namespace App\Workflows\WorkflowConfigs\Services;

use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;

interface WorkflowConfigServicesInterface
{
    /**
     * @return WorkflowConfig[]
     */
    function getListOfWorkflowConfigs(): array;
}