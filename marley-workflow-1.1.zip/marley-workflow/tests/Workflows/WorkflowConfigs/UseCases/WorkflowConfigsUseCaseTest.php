<?php

namespace App\Tests\Workflows\WorkflowConfigs\UseCases;

use PHPUnit\Framework\TestCase;

use App\Workflows\WorkflowConfigs\UseCases\WorkflowConfigUseCases;
use App\Workflows\WorkflowConfigs\Services\WorkflowConfigServices;

class WorkflowConfigsUseCasesTest extends TestCase
{
    public function test_getListOfWorkflowConfigs_checkServiceIsCalled(): void
    {
        $mocked_service = $this->createMock(WorkflowConfigServices::class);
        $mocked_service->expects($this->once())
            ->method('getListOfWorkflowConfigs');
        
        $workflow_config_use_cases = new WorkflowConfigUseCases();

        $reflection = new \ReflectionClass($workflow_config_use_cases);
        $reflection_property = $reflection->getProperty('workflow_config_services');
        $reflection_property->setAccessible(true);
        $reflection_property->setValue($workflow_config_use_cases, $mocked_service);

        $workflow_config_use_cases->getListOfWorkflowConfigs();
    }

    public function test_getWorkflowConfig_checkServiceIsCalled(): void
    {
        $mocked_service = $this->createMock(WorkflowConfigServices::class);
        $mocked_service->expects($this->once())
            ->method('getWorkflowConfig');
        
        $workflow_config_use_cases = new WorkflowConfigUseCases();

        $reflection = new \ReflectionClass($workflow_config_use_cases);
        $reflection_property = $reflection->getProperty('workflow_config_services');
        $reflection_property->setAccessible(true);
        $reflection_property->setValue($workflow_config_use_cases, $mocked_service);

        $workflow_config_use_cases->getWorkflowConfig('377d2823-135f-48bc-985a-7b07847d8901');
    }
}
