<?php

namespace App\Workflows\WorkflowConfigs\UseCases;

use App\Workflows\WorkflowConfigs\Services\WorkflowConfigServices;
use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;

class WorkflowConfigUseCases implements WorkflowConfigUseCasesInterface
{

    private $workflow_config_services;

    public function __construct()
    {
        $this->workflow_config_services = new WorkflowConfigServices();
    }


    /**
     * @return WorkflowConfig[]
     */
    public function getListOfWorkflowConfigs(): array
    {
        return $this->workflow_config_services->getListOfWorkflowConfigs();
    }

    /**
     * @return WorkflowConfig | null
     */
    public function getWorkflowConfig(string $id): ?WorkflowConfig
    {
        return $this->workflow_config_services->getWorkflowConfig($id);
    }
}