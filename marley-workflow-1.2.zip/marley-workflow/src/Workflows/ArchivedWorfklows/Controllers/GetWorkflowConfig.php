<?php

namespace App\Workflows\WorkflowConfigs\Controllers;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Attribute\AsController;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

use App\Workflows\WorkflowConfigs\UseCases\WorkflowConfigUseCases;

#[AsController]
class GetWorkflowConfig extends AbstractController
{

    private $workflow_config_use_cases;

    public function __construct(WorkflowConfigUseCases $workflow_config_use_cases)
    {
        $this->workflow_config_use_cases = $workflow_config_use_cases;
    }

    /**
	 * @Route(
	 *     name="get_workflow_config",
	 *     path="/workflows/configs/{id}",
	 *     methods={"GET"},
     *     requirements={"id" = "[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}"}
	 * )
	 */
    public function __invoke(string $id): JsonResponse
    {
        $workflow_config = $this->workflow_config_use_cases->getWorkflowConfig($id);

        if(empty($workflow_config)){
            throw new NotFoundHttpException; 
        }

        return $this->json($workflow_config);
    }
}
