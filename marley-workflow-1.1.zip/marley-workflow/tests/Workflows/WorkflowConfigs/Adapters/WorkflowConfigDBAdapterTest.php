<?php

namespace App\Tests\Workflows\WorkflowConfigs\Adapters;

use PHPUnit\Framework\TestCase;

use App\Workflows\WorkflowConfigs\Adapters\WorkflowConfigDBAdapter;
use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;

class WorkflowConfigDBAdapterTest extends TestCase
{
    public function test_getListOfWorkflowConfigs_checkReturnedCountIsValid(): void
    {
        $workflow_config_services = new WorkflowConfigDBAdapter();

        $workflow_config_list = $workflow_config_services->getListOfWorkflowConfigs();

        $this->assertCount(3, $workflow_config_list);
    }

    public function test_getListOfWorkflowConfigs_checkReturnedTypeIsValid(): void
    {
        $workflow_config_services = new WorkflowConfigDBAdapter();

        $workflow_config_list = $workflow_config_services->getListOfWorkflowConfigs();

        foreach($workflow_config_list as $workflow_config) {
            $this->assertInstanceOf(WorkflowConfig::class, $workflow_config);
        }
    }

    public function test_getWorkflowConfig_checkEmptyReturnIfNotFound(): void
    {
        $workflow_config_services = new WorkflowConfigDBAdapter();

        $workflow_config = $workflow_config_services->getWorkflowConfigById('invalid');

        $this->assertNull($workflow_config);
    }

    public function test_getWorkflowConfig_checkReturnIsValidIfFound(): void
    {
        $workflow_config_services = new WorkflowConfigDBAdapter();

        $workflow_config = $workflow_config_services->getWorkflowConfigById('377d2823-135f-48bc-985a-7b07847d8901');

        $this->assertInstanceOf(WorkflowConfig::class, $workflow_config);
    }
}
