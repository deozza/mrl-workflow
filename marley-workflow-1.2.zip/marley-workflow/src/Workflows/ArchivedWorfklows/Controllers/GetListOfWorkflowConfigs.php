<?php

namespace App\Workflows\ArchivedWorkflows\Controllers;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Attribute\AsController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;


#[AsController]
class GetListOfArchivedWorkflows extends AbstractController
{

    /**
	 * @Route(
	 *     name="get_archived_archived_workflow",
	 *     path="/workflows/archived",
	 *     methods={"GET"},
	 * )
	 */
    public function __invoke(): JsonResponse
    {
        $archived_workflow_1 = new ArchivedWorkflow();
        $archived_workflow_1->setId('377d2823-135f-48bc-985a-7b07847d8901');
        $archived_workflow_1->setName('workflow config 1');

        $archived_workflow_2 = new ArchivedWorkflow();
        $archived_workflow_2->setId('377d2823-135f-48bc-985a-7b07847d8902');
        $archived_workflow_2->setName('workflow config 2');


        $archived_workflow_3 = new ArchivedWorkflow();
        $archived_workflow_3->setId('377d2823-135f-48bc-985a-7b07847d8903');
        $archived_workflow_3->setName('workflow config 3');

        $archived_workflow_fixtures = [
            $archived_workflow_1,
            $archived_workflow_2,
            $archived_workflow_3
        ];

        return $this->json($archived_workflow_fixtures);
    }
}
