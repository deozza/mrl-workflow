<?php

namespace App\Workflows\WorkflowConfigs\UseCases;

use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;

interface WorkflowConfigUseCasesInterface
{
    /**
     * @return WorkflowConfig[]
     */
    function getListOfWorkflowConfigs(): array;
}