<?php

namespace App\Tests\Workflows\WorkflowConfigs\Services;

use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;

use App\Workflows\WorkflowConfigs\Services\WorkflowConfigServices;
use App\Workflows\WorkflowConfigs\Adapters\WorkflowConfigDBAdapter;

use Symfony\Component\Form\FormFactoryInterface;

class WorkflowConfigServicesTest extends KernelTestCase
{
    private $form_factory;

    protected function setUp(): void
    {
        self::bootKernel();
        $this->form_factory = static::getContainer()->get(FormFactoryInterface::class);
    }
    /*
    public function test_getListOfWorkflowConfigs_checkAdapterIsCalled(): void
    {
        $mocked_adapter = $this->createMock(WorkflowConfigDBAdapter::class);
        $mocked_adapter->expects($this->once())
            ->method('getListOfWorkflowConfigs');
        
        $service = new WorkflowConfigServices($this->form_factory);

        $service->getListOfWorkflowConfigs();
    }
    */
    
}
