<?php

namespace App\Workflows\WorkflowConfigs\Services;

use Symfony\Component\HttpFoundation\Request;

use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;

interface WorkflowConfigServicesInterface
{
    /**
     * @return WorkflowConfig[]
     */
    function getListOfWorkflowConfigs(): array;

    /**
     * @param string $id
     * @return WorkflowConfig | null
     */
    function getWorkflowConfig(string $id): ?WorkflowConfig;

    /**
     * @param Request $request
     * @return WorkflowConfig | array
     */
    function createWorkflowConfigFormValidation(Request $request);

    /**
     * @param Request $request
     * @param WorkflowConfig $workflow_config
     * @return WorkflowConfig | array
     */
    function patchWorkflowConfigFormValidation(WorkflowConfig $workflow_config, Request $request);

    /**
     * @param WorkflowConfig $workflow_config
     * @return WorkflowConfig | null
     */
    function saveNewWorkflowConfig(WorkflowConfig $workflow_config): WorkflowConfig;

    /**
     * @param WorkflowConfig $workflow_config
     * @return WorkflowConfig | null
     */
    function updateWorkflowConfig(WorkflowConfig $workflow_config): WorkflowConfig;
}