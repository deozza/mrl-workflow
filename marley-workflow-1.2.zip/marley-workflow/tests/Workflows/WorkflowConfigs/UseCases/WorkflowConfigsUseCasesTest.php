<?php

namespace App\Tests\Workflows\WorkflowConfigs\UseCases;

use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use Symfony\Component\HttpFoundation\Request;

use App\Workflows\WorkflowConfigs\UseCases\WorkflowConfigUseCases;
use App\Workflows\WorkflowConfigs\Services\WorkflowConfigServices;

class WorkflowConfigsUseCasesTest extends KernelTestCase
{

    private $workflow_config_services;

    protected function setUp(): void
    {
        self::bootKernel();
        $this->workflow_config_services = static::getContainer()->get(WorkflowConfigServices::class);
    }

    public function test_getListOfWorkflowConfigs_checkServiceIsCalled(): void
    {
        $mocked_service = $this->createMock(WorkflowConfigServices::class);
        $mocked_service->expects($this->once())
            ->method('getListOfWorkflowConfigs');
        
        $workflow_config_use_cases = new WorkflowConfigUseCases($this->workflow_config_services);

        $reflection = new \ReflectionClass($workflow_config_use_cases);
        $reflection_property = $reflection->getProperty('workflow_config_services');
        $reflection_property->setAccessible(true);
        $reflection_property->setValue($workflow_config_use_cases, $mocked_service);

        $workflow_config_use_cases->getListOfWorkflowConfigs();
    }

    public function test_getWorkflowConfig_checkServiceIsCalled(): void
    {
        $mocked_service = $this->createMock(WorkflowConfigServices::class);
        $mocked_service->expects($this->once())
            ->method('getWorkflowConfig');
        
        $workflow_config_use_cases = new WorkflowConfigUseCases($this->workflow_config_services);

        $reflection = new \ReflectionClass($workflow_config_use_cases);
        $reflection_property = $reflection->getProperty('workflow_config_services');
        $reflection_property->setAccessible(true);
        $reflection_property->setValue($workflow_config_use_cases, $mocked_service);

        $workflow_config_use_cases->getWorkflowConfig('377d2823-135f-48bc-985a-7b07847d8901');
    }

    public function test_createWorkflowConfig_checkServiceIsCalledWithInvalidForm(): void
    {
        $expected_new_workflow_config = new WorkflowConfig();
        $mocked_service = $this->createMock(WorkflowConfigServices::class);
        $mocked_service->expects($this->once())
            ->method('createWorkflowConfigFormValidation')
            ->will($this->returnValue([]));

        $mocked_service->expects($this->never())
            ->method('saveNewWorkflowConfig');
        
        $workflow_config_use_cases = new WorkflowConfigUseCases($this->workflow_config_services);

        $reflection = new \ReflectionClass($workflow_config_use_cases);
        $reflection_property = $reflection->getProperty('workflow_config_services');
        $reflection_property->setAccessible(true);
        $reflection_property->setValue($workflow_config_use_cases, $mocked_service);

        $request = Request::create(
            '/',
            'POST',
            [
                'name' => 'Fabien',
                'description' => 'workflow description',
                'expected_days_spent' => '-10'
            ],

        );

        $workflow_config_use_cases->createWorkflowConfig($request);
    }

    public function test_createWorkflowConfig_checkServiceIsCalledWithValidForm(): void
    {
        $expected_new_workflow_config = new WorkflowConfig();
        $mocked_service = $this->createMock(WorkflowConfigServices::class);
        $mocked_service->expects($this->once())
            ->method('createWorkflowConfigFormValidation')
            ->will($this->returnValue($expected_new_workflow_config));

        $mocked_service->expects($this->once())
            ->method('saveNewWorkflowConfig');
        
        $workflow_config_use_cases = new WorkflowConfigUseCases($this->workflow_config_services);

        $reflection = new \ReflectionClass($workflow_config_use_cases);
        $reflection_property = $reflection->getProperty('workflow_config_services');
        $reflection_property->setAccessible(true);
        $reflection_property->setValue($workflow_config_use_cases, $mocked_service);

        $request = Request::create(
            '/',
            'POST',
            [
                'name' => 'Fabien',
                'description' => 'workflow description',
                'expected_days_spent' => '10'
            ],

        );

        $workflow_config_use_cases->createWorkflowConfig($request);
    }

    public function test_updateWorkflowConfig_checkServiceIsCalledWithInvalidId(): void
    {
        $mocked_service = $this->createMock(WorkflowConfigServices::class);
        $mocked_service->expects($this->once())
            ->method('getWorkflowConfig')
            ->will($this->returnValue(null));

        $mocked_service->expects($this->never())
            ->method('patchWorkflowConfigFormValidation');
        
        $workflow_config_use_cases = new WorkflowConfigUseCases($this->workflow_config_services);

        $reflection = new \ReflectionClass($workflow_config_use_cases);
        $reflection_property = $reflection->getProperty('workflow_config_services');
        $reflection_property->setAccessible(true);
        $reflection_property->setValue($workflow_config_use_cases, $mocked_service);

        $request = Request::create(
            '/',
            'POST',
            [
                'name' => 'Fabien',
                'description' => 'workflow description',
                'expected_days_spent' => '10'
            ],

        );

        $workflow_config_use_cases->updateWorkflowConfig('invalid', $request);
    }

    public function test_updateWorkflowConfig_checkServiceIsCalledWithInvalidForm(): void
    {
        $expected_workflow_config = new WorkflowConfig();
        $mocked_service = $this->createMock(WorkflowConfigServices::class);
        $mocked_service->expects($this->once())
            ->method('getWorkflowConfig')
            ->will($this->returnValue($expected_workflow_config));

        $mocked_service->expects($this->once())
            ->method('patchWorkflowConfigFormValidation')
            ->will($this->returnValue([]));

        $mocked_service->expects($this->never())
            ->method('updateWorkflowConfig');
        
        $workflow_config_use_cases = new WorkflowConfigUseCases($this->workflow_config_services);

        $reflection = new \ReflectionClass($workflow_config_use_cases);
        $reflection_property = $reflection->getProperty('workflow_config_services');
        $reflection_property->setAccessible(true);
        $reflection_property->setValue($workflow_config_use_cases, $mocked_service);

        $request = Request::create(
            '/',
            'PATCH',
            [
                'name' => 'Fabien',
                'description' => 'workflow description',
                'expected_days_spent' => '-10'
            ],

        );

        $workflow_config_use_cases->updateWorkflowConfig('377d2823-135f-48bc-985a-7b07847d8901', $request);
    }
}
