<?php

namespace App\Workflows\WorkflowConfigs\UseCases;

use Symfony\Component\HttpFoundation\Request;

use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;

interface WorkflowConfigUseCasesInterface
{
    /**
     * @return WorkflowConfig[]
     */
    function getListOfWorkflowConfigs(): array;

    /**
     * @param string $id
     * @return WorkflowConfig | null
     */
    function getWorkflowConfig(string $id): ?WorkflowConfig;

    /**
     * @param Request $request
     * @return WorkflowConfig | null
     */
    function createWorkflowConfig(Request $request): ?WorkflowConfig;

    /**
     * @param Request $request
     * @param string $id
     * @return WorkflowConfig | null
     */
    function updateWorkflowConfig(string $id, Request $request): ?WorkflowConfig;
}