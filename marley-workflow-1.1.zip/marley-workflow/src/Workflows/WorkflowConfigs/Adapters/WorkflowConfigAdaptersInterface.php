<?php

namespace App\Workflows\WorkflowConfigs\Adapters;

use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;

interface WorkflowConfigAdaptersInterface
{
    /**
     * @return WorkflowConfig[]
     */
    function getListOfWorkflowConfigs(): array;

    /**
     * @param string $id
     * @return WorkflowConfig | null
     */
    function getWorkflowConfigById(string $id): ?WorkflowConfig;

    /**
     * @param WorkflowConfig $workflow_config
     * @param bool $is_new
     * @return WorkflowConfig
     */
    function saveWorkflowConfig(WorkflowConfig $workflow_config, bool $is_new): WorkflowConfig;

}