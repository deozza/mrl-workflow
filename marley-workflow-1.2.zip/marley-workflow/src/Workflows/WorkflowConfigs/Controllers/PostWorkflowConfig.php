<?php

namespace App\Workflows\WorkflowConfigs\Controllers;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Attribute\AsController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Exception\BadRequestException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

use App\Workflows\WorkflowConfigs\UseCases\WorkflowConfigUseCases;

#[AsController]
class PostWorkflowConfig extends AbstractController
{

    private $workflow_config_use_cases;

    public function __construct(WorkflowConfigUseCases $workflow_config_use_cases)
    {
        $this->workflow_config_use_cases = $workflow_config_use_cases;
    }

    /**
	 * @Route(
	 *     name="post_workflow_config",
	 *     path="/workflows/configs",
	 *     methods={"POST"},
	 * )
	 */
    public function __invoke(Request $request): JsonResponse
    {
        $workflow_config = $this->workflow_config_use_cases->createWorkflowConfig($request);

        if(is_array($workflow_config)){
            return $this->json($workflow_config, 400);
        }

        return $this->json($workflow_config, 201);
    }
}
