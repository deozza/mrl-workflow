<?php

namespace App\Tests\Workflows\WorkflowConfigs\Controllers;

use ApiPlatform\Core\Bridge\Symfony\Bundle\Test\ApiTestCase;

class GetWorkflowConfigTest extends ApiTestCase
{

    /**
     * @dataProvider dataprovider_getWorkflowConfig_checkInvalidMethodReturnsError
     */
    public function test_getWorkflowConfig_checkInvalidMethodReturnsError(string $method): void {
        $response = static::createClient()->request($method, '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8901');
        $this->assertResponseStatusCodeSame(405);
    }

    public function dataprovider_getWorkflowConfig_checkInvalidMethodReturnsError(): array {
        return [
            ['POST'],
            ['PUT'],
            ['DELETE']
        ];
    }

    public function test_getWorkflowConfig_checkNotFoundWithInvalidParameter(): void {
        $response = static::createClient()->request('GET', '/workflows/configs/invalid');
        $this->assertResponseStatusCodeSame(404);
    }

    public function test_getWorkflowConfig_checkNotFoundWithUnknownId(): void {
        $response = static::createClient()->request('GET', '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8910');
        $this->assertResponseStatusCodeSame(404);
    }

    public function test_getWorkflowConfig_checkReturnedValueIsValid(): void {
        $response = static::createClient()->request('GET', '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8901');
        $this->assertResponseStatusCodeSame(200);
        $this->assertResponseHeaderSame('content-type', 'application/json');

        $response_content = $response->toArray();

		$this->assertEquals('377d2823-135f-48bc-985a-7b07847d8901', $response_content['id']);
    }

}
