<?php

namespace App\Tests\Workflows\WorkflowConfigs\Controllers;

use ApiPlatform\Core\Bridge\Symfony\Bundle\Test\ApiTestCase;

class PatchWorkflowConfigTest extends ApiTestCase
{

    /**
     * @dataProvider dataprovider_patchWorkflowConfig_checkInvalidMethodReturnsError
     */
    public function test_patchWorkflowConfig_checkInvalidMethodReturnsError(string $method): void {
        $response = static::createClient()->request($method, '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8901');
        $this->assertResponseStatusCodeSame(405);
    }

    public function dataprovider_patchWorkflowConfig_checkInvalidMethodReturnsError(): array {
        return [
            ['POST'],
            ['PUT'],
            ['DELETE']
        ];
    }

    public function test_patchWorkflowConfig_checkNotFoundWithInvalidId(): void {
        $response = static::createClient()->request('PATCH', '/workflows/configs/invalid');
        $this->assertResponseStatusCodeSame(404);
    }

    public function test_patchWorkflowConfig_checkNotFoundWithUnknownId(): void {
        $response = static::createClient()->request('PATCH', '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8910');
        $this->assertResponseStatusCodeSame(404);
    }

    public function test_patchWorkflowConfig_checkReturnedValueIfInvalidBody(): void {
        $response = static::createClient()->request('PATCH', '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8901');
        $this->assertResponseStatusCodeSame(404);
    }

    public function test_patchWorkflowConfig_checkReturnedValueIfValidBody(): void {
        $response = static::createClient()->request('GET', '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8901');
        $this->assertResponseStatusCodeSame(200);
        $this->assertResponseHeaderSame('content-type', 'application/json');

        $response_content = $response->toArray();

		$this->assertEquals('workflow config 1', $response_content['name']);

        $response = static::createClient()->request('PATCH', '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8901');
        $this->assertResponseStatusCodeSame(200);
        $this->assertResponseHeaderSame('content-type', 'application/json');

        $response_content = $response->toArray();

		$this->assertEquals('patched workflow config 1', $response_content['name']);
    }

}
