<?php

namespace App\Workflows\WorkflowConfigs\Controllers;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Attribute\AsController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Exception\BadRequestException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

use App\Workflows\WorkflowConfigs\UseCases\WorkflowConfigUseCases;

#[AsController]
class PostWorkflowConfig extends AbstractController
{
    /**
	 * @Route(
	 *     name="get_workflow_config",
	 *     path="/workflows/configs",
	 *     methods={"POST"},
	 * )
	 */
    public function __invoke(Request $request): JsonResponse
    {
        $workflow_config_use_cases = new WorkflowConfigUseCases();

        $workflow_config = $workflow_config_use_cases->createWorkflowConfig($request);

        if(empty($workflow_config)){
            throw new BadRequestException; 
        }

        return $this->json($workflow_config);
    }
}
