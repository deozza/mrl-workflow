<?php

namespace App\Workflows\WorkflowConfigs\UseCases;

use Symfony\Component\HttpFoundation\Request;

use App\Workflows\WorkflowConfigs\Services\WorkflowConfigServices;
use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;


class WorkflowConfigUseCases implements WorkflowConfigUseCasesInterface
{

    private $workflow_config_services;

    public function __construct(WorkflowConfigServices $workflow_config_services)
    {
        $this->workflow_config_services = $workflow_config_services;
    }


    /**
     * @return WorkflowConfig[]
     */
    public function getListOfWorkflowConfigs(): array
    {
        return $this->workflow_config_services->getListOfWorkflowConfigs();
    }

    /**
     * @return WorkflowConfig | null
     */
    public function getWorkflowConfig(string $id): ?WorkflowConfig
    {
        return $this->workflow_config_services->getWorkflowConfig($id);
    }

    /**
     * @param Request $request
     * @return WorkflowConfig | array
     */
    public function createWorkflowConfig(Request $request)
    {
        $workflow_config = $this->workflow_config_services->createWorkflowConfigFormValidation($request);

        if(is_array($workflow_config)){
            return $workflow_config;
        }
        
        $this->workflow_config_services->saveNewWorkflowConfig($workflow_config);

        return $workflow_config;
    }

    /**
     * @param Request $request
     * @param string $id
     * @return WorkflowConfig | array | null
     */
    public function updateWorkflowConfig(string $id, Request $request)
    {
        $workflow_config = $this->workflow_config_services->getWorkflowConfig($id);

        if(empty($workflow_config)){
            return null;
        }
        
        $updated_workflow_config = $this->workflow_config_services->patchWorkflowConfigFormValidation($workflow_config, $request);

        if(is_array($updated_workflow_config)){
            return $updated_workflow_config;
        }

        $this->workflow_config_services->updateWorkflowConfig($updated_workflow_config);

        return $updated_workflow_config;
    }
}