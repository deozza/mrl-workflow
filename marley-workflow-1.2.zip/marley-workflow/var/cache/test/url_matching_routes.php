<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/workflows/configs' => [
            [['_route' => 'get_workflow_config_list', '_controller' => 'App\\Workflows\\WorkflowConfigs\\Controllers\\GetListOfWorkflowConfigs'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'post_workflow_config', '_controller' => 'App\\Workflows\\WorkflowConfigs\\Controllers\\PostWorkflowConfig'], null, ['POST' => 0], null, false, false, null],
        ],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/workflows/configs/([0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})(?'
                    .'|(*:98)'
                .')'
                .'|/api(?'
                    .'|(?:/(index)(?:\\.([^/]++))?)?(*:141)'
                    .'|/(?'
                        .'|docs(?:\\.([^/]++))?(*:172)'
                        .'|contexts/(.+)(?:\\.([^/]++))?(*:208)'
                    .')'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        98 => [
            [['_route' => 'get_workflow_config', '_controller' => 'App\\Workflows\\WorkflowConfigs\\Controllers\\GetWorkflowConfig'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'patch_workflow_config', '_controller' => 'App\\Workflows\\WorkflowConfigs\\Controllers\\PatchWorkflowConfig'], ['id'], ['PATCH' => 0], null, false, true, null],
        ],
        141 => [[['_route' => 'api_entrypoint', '_controller' => 'api_platform.action.entrypoint', '_format' => '', '_api_respond' => 'true', 'index' => 'index'], ['index', '_format'], null, null, false, true, null]],
        172 => [[['_route' => 'api_doc', '_controller' => 'api_platform.action.documentation', '_format' => '', '_api_respond' => 'true'], ['_format'], null, null, false, true, null]],
        208 => [
            [['_route' => 'api_jsonld_context', '_controller' => 'api_platform.jsonld.action.context', '_format' => 'jsonld', '_api_respond' => 'true'], ['shortName', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
