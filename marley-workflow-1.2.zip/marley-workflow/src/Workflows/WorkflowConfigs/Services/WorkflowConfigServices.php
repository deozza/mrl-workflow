<?php

namespace App\Workflows\WorkflowConfigs\Services;

use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;
use App\Workflows\WorkflowConfigs\Adapters\WorkflowConfigDBAdapter;
use App\Workflows\WorkflowConfigs\Adapters\Forms\EditWorkflowConfigType;
use App\Workflows\WorkflowConfigs\Adapters\Forms\CreateWorkflowConfigType;
use App\Utils\FormUtils;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\FormFactoryInterface;

class WorkflowConfigServices implements WorkflowConfigServicesInterface
{

    private $form_factory;
    
    public function __construct(FormFactoryInterface $form_factory)
    {
        $this->form_factory = $form_factory;
    }

    /**
     * @return WorkflowConfig[]
     */
    public function getListOfWorkflowConfigs(): array
    {
        $workflow_config_adapter = new WorkflowConfigDBAdapter();

        return $workflow_config_adapter->getListOfWorkflowConfigs();
    }

    /**
     * @param string $id
     * @return WorkflowConfig | null
     */
    public function getWorkflowConfig(string $id): ?WorkflowConfig
    {
        $workflow_config_adapter = new WorkflowConfigDBAdapter();

        return $workflow_config_adapter->getWorkflowConfigById($id);
    }

    /**
     * @param Request $request
     * @return WorkflowConfig | array
     */
    public function createWorkflowConfigFormValidation(Request $request)
    {
        $workflow_config = new WorkflowConfig();        
        $form = $this->form_factory->create(CreateWorkflowConfigType::class, $workflow_config);

        $payload = json_decode($request->getContent(), true);

        $form->submit($payload);

        if(!$form->isvalid())
        {
            return FormUtils::getSerializedFormErrors($form);
        }

        return $workflow_config;
    }

    /**
     * @param Request $request
     * @param WorkflowConfig $workflow_config
     * @return WorkflowConfig | array
     */
    public function patchWorkflowConfigFormValidation(WorkflowConfig $workflow_config, Request $request)
    {
        $form = $this->form_factory->create(EditWorkflowConfigType::class, $workflow_config);

        $payload = json_decode($request->getContent(), true);

        $form->submit($payload, $clear_missing = false);

        if(!$form->isvalid())
        {
            return FormUtils::getSerializedFormErrors($form);
        }

        return $workflow_config;
    }

    /**
     * @param WorkflowConfig $workflow_config
     * @return WorkflowConfig | null
     */
    public function saveNewWorkflowConfig(WorkflowConfig $workflow_config): WorkflowConfig
    {
        $workflow_config_adapter = new WorkflowConfigDBAdapter();

        return $workflow_config_adapter->saveWorkflowConfig($workflow_config, $is_new = true);
    }

    /**
     * @param WorkflowConfig $workflow_config
     * @return WorkflowConfig | null
     */
    public function updateWorkflowConfig(WorkflowConfig $workflow_config): WorkflowConfig
    {
        $workflow_config_adapter = new WorkflowConfigDBAdapter();

        return $workflow_config_adapter->saveWorkflowConfig($workflow_config, $is_new = false);
    }

}