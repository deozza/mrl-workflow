<?php

namespace App\Workflows\WorkflowConfigs\Adapters;

use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;

interface WorkflowConfigAdaptersInterface
{
    /**
     * @return WorkflowConfig[]
     */
    function getListOfWorkflowConfigs(): array;
}