<?php

namespace App\Workflows\WorkflowConfigs\Services;

use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;
use App\Workflows\WorkflowConfigs\Adapters\WorkflowConfigDBAdapter;

class WorkflowConfigServices implements WorkflowConfigServicesInterface
{
    /**
     * @return WorkflowConfig[]
     */
    public function getListOfWorkflowConfigs(): array
    {
        $workflow_config_adapter = new WorkflowConfigDBAdapter();

        return $workflow_config_adapter->getListOfWorkflowConfigs();
    }

    /**
     * @param string $id
     * @return WorkflowConfig | null
     */
    public function getWorkflowConfig(string $id): ?WorkflowConfig
    {
        $workflow_config_adapter = new WorkflowConfigDBAdapter();

        return $workflow_config_adapter->getWorkflowConfigById($id);
    }
}