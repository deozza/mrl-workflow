<?php

namespace App\Workflows\WorkflowConfigs\Controllers;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Attribute\AsController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

use App\Workflows\WorkflowConfigs\UseCases\WorkflowConfigUseCases;

#[AsController]
class GetListOfWorkflowConfigs extends AbstractController
{

    private $workflow_config_use_cases;

    public function __construct(WorkflowConfigUseCases $workflow_config_use_cases)
    {
        $this->workflow_config_use_cases = $workflow_config_use_cases;
    }

    /**
	 * @Route(
	 *     name="get_workflow_config_list",
	 *     path="/workflows/configs",
	 *     methods={"GET"},
	 * )
	 */
    public function __invoke(): JsonResponse
    {
        $workflow_config_list = $this->workflow_config_use_cases->getListOfWorkflowConfigs();

        return $this->json($workflow_config_list);
    }
}
