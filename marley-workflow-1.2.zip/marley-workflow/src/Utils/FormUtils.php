<?php

namespace App\Utils;

use Symfony\Component\Form\FormInterface;

class FormUtils {
    public static function getSerializedFormErrors(FormInterface $form){
        $errors = [];
        foreach ($form->getErrors() as $error) {
            $errors[] = $error->getMessage();
        }
        foreach ($form->all() as $childForm) {
            if ($childForm instanceof FormInterface) {
                if ($childErrors = self::getSerializedFormErrors($childForm)) {
                    $errors[$childForm->getName()] = $childErrors;
                }
            }
        }
        return $errors;
    }
}