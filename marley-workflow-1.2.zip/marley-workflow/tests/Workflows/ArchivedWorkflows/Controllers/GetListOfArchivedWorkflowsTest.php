<?php

namespace App\Tests\Workflows\ArchivedWorkflows\Controllers;

use ApiPlatform\Core\Bridge\Symfony\Bundle\Test\ApiTestCase;

class GetListOfArchivedWorkflowsTest extends ApiTestCase
{

    /**
     * @dataProvider dataprovider_getListOfArchivedWorkflows_checkInvalidMethodReturnsError
     */
    public function test_getListOfArchivedWorkflows_checkInvalidMethodReturnsError(string $method): void {
        $response = static::createClient()->request($method, '/workflows/archived');
        $this->assertResponseStatusCodeSame(405);
    }

    public function dataprovider_getListOfArchivedWorkflows_checkInvalidMethodReturnsError(): array {
        return [
            ['POST'],
            ['PATCH'],
            ['PUT'],
            ['DELETE']
        ];
    }

    public function test_getListOfArchivedWorkflowss_checkReturnedValueIsValid(): void {
        $response = static::createClient()->request('GET', '/workflows/archived');
        $this->assertResponseStatusCodeSame(200);
        $this->assertResponseHeaderSame('content-type', 'application/json');

        $response_content = $response->toArray();

		$this->assertCount(3, $response_content);
    }

}
