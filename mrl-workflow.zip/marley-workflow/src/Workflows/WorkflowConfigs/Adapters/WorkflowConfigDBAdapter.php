<?php

namespace App\Workflows\WorkflowConfigs\Adapters;

use App\Workflows\WorkflowConfigs\Adapters\WorkflowConfigAdaptersInterface;
use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;

class WorkflowConfigDBAdapter implements WorkflowConfigAdaptersInterface
{
    /**
     * @return WorkflowConfig[]
     */
    public function getListOfWorkflowConfigs(): array
    {
        $workflow_config_1 = new WorkflowConfig();
        $workflow_config_2 = new WorkflowConfig();
        $workflow_config_3 = new WorkflowConfig();

        return [
            $workflow_config_1,
            $workflow_config_2,
            $workflow_config_3
        ];
    }
}