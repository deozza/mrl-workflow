<?php

namespace App\Workflows\WorkflowConfigs\Entities;

use Symfony\Component\Uid\Uuid;
use Symfony\Component\Uid\UuidV4;
use Doctrine\ORM\Mapping as ORM;


class WorkflowConfig {

    private $id;
    private $date_creation;
    private $date_last_update;
    private $creator_id;
    private $asset_kind_id;
    private $country_id;
    private $description;
    private $name;
    private $expected_days_spent;
    private $step_config_id_list;

    public function __construct()
    {
        $this->setId(null);
        $this->setDateCreation();
        $this->setDateLastUpdate($this->date_creation);
    }
    
    /**
     * Get the value of id
     */
    public function getId(): UuidV4
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?string $id): self
    {
        if(empty($id)){
            $id = Uuid::v4();
        }else{
            $id= Uuid::fromString($id);
        }
        $this->id = $id;
        
        return $this;
    }

    /**
     * Get the value of date_creation
     */
    public function getDateCreation(): \DateTime
    {
        return $this->date_creation;
    }

    /**
     * Set the value of date_creation
     */
    private function setDateCreation(): self
    {
        $this->date_creation = new \DateTime('now');

        return $this;
    }

    /**
     * Get the value of date_last_update
     */
    public function getDateLastUpdate(): \DateTime
    {
        return $this->date_last_update;
    }

    /**
     * Set the value of date_last_update
     */
    public function setDateLastUpdate(\DateTime $date_last_update): self
    {
        $this->date_last_update = $date_last_update;

        return $this;
    }

    /**
     * Get the value of creator_id
     */
    public function getCreatorId(): string
    {
        return $this->creator_id;
    }

    /**
     * Set the value of creator_id
     */
    public function setCreatorId(string $creator_id): self
    {
        $this->creator_id = $creator_id;

        return $this;
    }

    /**
     * Get the value of asset_kind_id
     */
    public function getAssetKindId(): string
    {
        return $this->asset_kind_id;
    }

    /**
     * Set the value of asset_kind_id
     */
    public function setAssetKindId(string $asset_kind_id): self
    {
        $this->asset_kind_id = $asset_kind_id;

        return $this;
    }

    /**
     * Get the value of country_id
     */
    public function getCountryId(): string
    {
        return $this->country_id;
    }

    /**
     * Set the value of country_id
     */
    public function setCountryId(string $country_id): self
    {
        $this->country_id = $country_id;

        return $this;
    }

    /**
     * Get the value of description
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * Set the value of description
     */
    public function setDescription(string $description): self
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get the value of name
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Set the value of name
     */
    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get the value of expected_days_spent
     */
    public function getExpectedDaysSpent(): float
    {
        return $this->expected_days_spent;
    }

    /**
     * Set the value of expected_days_spent
     */
    public function setExpectedDaysSpent(float $expected_days_spent): self
    {
        $this->expected_days_spent = $expected_days_spent;

        return $this;
    }

    /**
     * Get the value of step_config_id_list
     */
    public function getStepConfigIdList(): array
    {
        return $this->step_config_id_list;
    }

    /**
     * Set the value of step_config_id_list
     */
    public function setStepConfigIdList(array $step_config_id_list): self
    {
        $this->step_config_id_list = $step_config_id_list;

        return $this;
    }
} 
