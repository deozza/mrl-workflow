<?php

namespace App\Workflows\WorkflowConfigs\Services;

use Symfony\Component\HttpFoundation\Request;

use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;

interface WorkflowConfigServicesInterface
{
    /**
     * @return WorkflowConfig[]
     */
    function getListOfWorkflowConfigs(): array;

    /**
     * @param string $id
     * @return WorkflowConfig | null
     */
    function getWorkflowConfig(string $id): ?WorkflowConfig;

    /**
     * @param Request $request
     * @return WorkflowConfig | null
     */
    function createWorkflowConfigFormValidation(Request $request): ?WorkflowConfig;

    /**
     * @param Request $request
     * @param WorkflowConfig $workflow_config
     * @return WorkflowConfig | null
     */
    function patchWorkflowConfigFormValidation(WorkflowConfig $workflow_config, Request $request): ?WorkflowConfig;

    /**
     * @param WorkflowConfig $workflow_config
     * @return WorkflowConfig | null
     */
    function saveNewWorkflowConfig(Request $request): WorkflowConfig;

    /**
     * @param WorkflowConfig $workflow_config
     * @return WorkflowConfig | null
     */
    function updateWorkflowConfig(WorkflowConfig $workflow_config): WorkflowConfig;
}