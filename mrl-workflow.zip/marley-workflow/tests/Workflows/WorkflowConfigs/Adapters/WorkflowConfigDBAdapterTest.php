<?php

namespace App\Tests\Workflows\WorkflowConfigs\Adapters;

use PHPUnit\Framework\TestCase;

use App\Workflows\WorkflowConfigs\Adapters\WorkflowConfigDBAdapter;
use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;

class WorkflowConfigDBAdapterTest extends TestCase
{
    public function test_getListOfWorkflowConfigs_checkReturnedCountIsValid(): void
    {
        $workflow_config_services = new WorkflowConfigDBAdapter();

        $workflow_config_list = $workflow_config_services->getListOfWorkflowConfigs();

        $this->assertCount(3, $workflow_config_list);
    }

    public function test_getListOfWorkflowConfigs_checkReturnedTypeIsValid(): void
    {
        $workflow_config_services = new WorkflowConfigDBAdapter();

        $workflow_config_list = $workflow_config_services->getListOfWorkflowConfigs();

        foreach($workflow_config_list as $workflow_config) {
            $this->assertInstanceOf(WorkflowConfig::class, $workflow_config);
        }
    }
}
