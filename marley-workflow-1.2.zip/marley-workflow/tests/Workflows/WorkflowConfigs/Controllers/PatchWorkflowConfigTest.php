<?php

namespace App\Tests\Workflows\WorkflowConfigs\Controllers;

use ApiPlatform\Core\Bridge\Symfony\Bundle\Test\ApiTestCase;

class PatchWorkflowConfigTest extends ApiTestCase
{

    /**
     * @dataProvider dataprovider_patchWorkflowConfig_checkInvalidMethodReturnsError
     */
    public function test_patchWorkflowConfig_checkInvalidMethodReturnsError(string $method): void {
        $response = static::createClient()->request($method, '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8901');
        $this->assertResponseStatusCodeSame(405);
    }

    public function dataprovider_patchWorkflowConfig_checkInvalidMethodReturnsError(): array {
        return [
            ['POST'],
            ['PUT'],
            ['DELETE']
        ];
    }

    public function test_patchWorkflowConfig_checkNotFoundWithInvalidId(): void {
        $response = static::createClient()->request('PATCH', '/workflows/configs/invalid');
        $this->assertResponseStatusCodeSame(404);
    }

    public function test_patchWorkflowConfig_checkNotFoundWithUnknownId(): void {
        $response = static::createClient()->request('PATCH', '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8910');
        $this->assertResponseStatusCodeSame(404);
    }

    public function test_patchWorkflowConfig_checkReturnedValueIfInvalidBody(): void {
        $response = static::createClient()->request('PATCH', '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8901', [
            'json' => 
            [
                'expected_days_spent' => -10
            ]
        ]);
        $this->assertResponseStatusCodeSame(400);
    }

    public function test_patchWorkflowConfig_checkReturnedValueIfValidBody(): void {
        $response_original_config = static::createClient()->request('GET', '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8901');
        $this->assertResponseStatusCodeSame(200);
        $this->assertResponseHeaderSame('content-type', 'application/json');

        $content_response_original_config = $response_original_config->toArray();

		$this->assertEquals('workflow config 1', $content_response_original_config['name']);

        $response_patch = static::createClient()->request('PATCH', '/workflows/configs/377d2823-135f-48bc-985a-7b07847d8901', [
            'json' => 
            [
                'name' => 'patched workflow config 1'
            ]
        ]);
        $this->assertResponseStatusCodeSame(200);
        $this->assertResponseHeaderSame('content-type', 'application/json');

		$this->assertEquals('patched workflow config 1', $response_patch->toArray()['name']);
    }

}
