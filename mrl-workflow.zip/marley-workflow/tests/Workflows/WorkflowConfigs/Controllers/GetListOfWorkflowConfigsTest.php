<?php

namespace App\Tests\Workflows\WorkflowConfigs\Controllers;

use ApiPlatform\Core\Bridge\Symfony\Bundle\Test\ApiTestCase;

class GetListOfWorkflowConfigsTest extends ApiTestCase
{

    /**
     * @dataProvider dataprovider_getAssetList_invalidMethod
     */
    public function test_getListOfWorkflowConfigs_checkInvalidMethodReturnsError(string $method): void {
        $response = static::createClient()->request($method, '/workflows/configs');
        $this->assertResponseStatusCodeSame(405);
    }

    public function dataprovider_getAssetList_invalidMethod(): array {
        return [
            ['POST'],
            ['PATCH'],
            ['PUT'],
            ['DELETE']
        ];
    }

    public function test_getListOfWorkflowConfigs_checkReturnedValueIsValid(): void {
        $response = static::createClient()->request('GET', '/workflows/configs');
        $this->assertResponseStatusCodeSame(200);
        $this->assertResponseHeaderSame('content-type', 'application/json');

        $response_content = $response->toArray();

		$this->assertCount(3, $response_content);
    }

}
