<?php

namespace App\Tests\Workflows\WorkflowConfigs\Controllers;

use ApiPlatform\Core\Bridge\Symfony\Bundle\Test\ApiTestCase;

class PostWorkflowConfigTest extends ApiTestCase
{

    /**
     * @dataProvider dataprovider_postListOfWorkflowConfig_checkInvalidMethodReturnsError
     */
    public function test_postListOfWorkflowConfig_checkInvalidMethodReturnsError(string $method): void {
        $response = static::createClient()->request($method, '/workflows/configs');
        $this->assertResponseStatusCodeSame(405);
    }

    public function dataprovider_postListOfWorkflowConfig_checkInvalidMethodReturnsError(): array {
        return [
            ['PATCH'],
            ['PUT'],
            ['DELETE']
        ];
    }

    public function test_postWorkflowConfig_checkReturnedValueIfInvalidBody(): void {
        $response = static::createClient()->request('POST', '/workflows/configs');
        $this->assertResponseStatusCodeSame(400);
    }

    public function test_postWorkflowConfig_checkReturnedValueIfValidBody(): void {
        $response = static::createClient()->request('POST', '/workflows/configs');
        $this->assertResponseStatusCodeSame(201);
        $this->assertResponseHeaderSame('content-type', 'application/json');

        $response_content = $response->toArray();

		$this->assertEquals('new workflow config', $response_content['name']);
    }
}
