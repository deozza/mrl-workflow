<?php

namespace App\Workflows\WorkflowConfigs\Adapters;

use App\Workflows\WorkflowConfigs\Adapters\WorkflowConfigAdaptersInterface;
use App\Workflows\WorkflowConfigs\Entities\WorkflowConfig;

class WorkflowConfigDBAdapter implements WorkflowConfigAdaptersInterface
{

    /**
     * @var WorkflowConfig[] $workflow_config_fixtures
     */
    private $workflow_config_fixtures = [];

    public function __construct()
    {
        $workflow_config_1 = new WorkflowConfig();
        $workflow_config_1->setId('377d2823-135f-48bc-985a-7b07847d8901');

        $workflow_config_2 = new WorkflowConfig();
        $workflow_config_3 = new WorkflowConfig();

        $this->workflow_config_fixtures = [
            $workflow_config_1,
            $workflow_config_2,
            $workflow_config_3
        ];
    }

    /**
     * @return WorkflowConfig[]
     */
    public function getListOfWorkflowConfigs(): array
    {
        return $this->workflow_config_fixtures;
    }

    /**
     * @param string $id
     * @return WorkflowConfig | null
     */
    public function getWorkflowConfigById(string $id): ?WorkflowConfig
    {
        foreach($this->workflow_config_fixtures as $workflow_config_fixture){

            if($workflow_config_fixture->getId()->toRfc4122() === $id){
                return $workflow_config_fixture;
            }
        }

        return null;
    }

}